スタックチャン LT会ジオラマ 印刷キット (2026-07-23版)
完成イメージ: https://stackchan-event-booth.pages.dev/viewer-booth/

■ 印刷する物と数量・色の希望(手持ち色でOK)
  floor-tile-corner.stl  x2   … 床(角・壁受け2辺)   濃い緑 or 群青
  floor-tile-wall.stl    x2   … 床(壁受け1辺)       同上
  wall-screen-l.stl      x1   … スクリーン壁 左     灰色
  wall-screen-r.stl      x1   … スクリーン壁 右     灰色(Lと同色で)
  wall-window.stl        x2   … 窓付き壁            クリア推奨(窓ガラス風!)
  wall-plain.stl         x2   … 通常壁              灰色
  podium.stl             x1   … 演台                黒
  stage.stl              x1   … ステージ台          黒
  合計 約7時間 / 約400g

■ 設定
  - PLA / ノズル0.4でも0.6でもOK / レイヤー0.2〜0.28 / インフィル10%
  - サポート不要・そのままの向きで印刷
  - podium だけインフィル8%推奨(中実形状のため)

※差し込み公差は大きめに取ってあるので多少の機差はOK。
  渋ければカッターで面取りしてください。ありがとうございます!!
